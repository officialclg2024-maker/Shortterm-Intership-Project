# Project Report – AI-Powered College Information Assistant

## 1. Introduction

Students frequently need information about admissions, departments, fees,
hostel facilities, examinations, transport, library services, and college
contacts. This project develops a conversational assistant that allows
students to ask these questions in natural language.

## 2. Problem Statement

Traditional college information systems often require students to search
multiple notices, web pages, or offices. A conversational AI assistant can
provide a single interface for frequently requested information.

## 3. Objectives

- Build a simple AI-powered college information assistant.
- Use Google Cloud Generative AI / Gemini for natural-language generation.
- Retrieve relevant college information before generating an answer.
- Reduce unsupported answers by restricting generation to the knowledge base.
- Deploy a web interface that can be demonstrated during an internship.

## 4. Technologies

- Python
- Streamlit
- Google Cloud Vertex AI
- Gemini
- JSON knowledge base
- Docker
- GitHub

## 5. Methodology

1. Student enters a question.
2. The application searches the college knowledge base.
3. Relevant records are selected.
4. The retrieved context is sent to Gemini through Vertex AI.
5. Gemini generates a concise response using the supplied context.
6. Relevant source titles are displayed.
7. If cloud credentials are unavailable, the application uses a local fallback.

## 6. Advantages

- Easy student interaction
- Natural-language questions
- Controlled information source
- Simple architecture
- Cloud-ready
- Easy to customize for different colleges

## 7. Limitations

The sample project uses a small JSON knowledge base and simple keyword
retrieval. A production implementation should use a larger verified corpus,
semantic retrieval / Vertex AI Search, authentication, monitoring, evaluation,
and regular content updates.

## 8. Future Enhancements

- Vertex AI Search / RAG
- PDF and website ingestion
- Multilingual support
- Voice input
- Student authentication
- Admin dashboard
- Analytics and feedback
- Automated document updates
- Evaluation of answer quality and groundedness

## 9. Conclusion

The project demonstrates how Google Cloud Generative AI can be used to build a
college-focused conversational assistant. It provides a practical foundation
for a B.Tech internship project and can be expanded into a production-oriented
RAG application.
