
import json
import os
from pathlib import Path

DATA_PATH = Path(__file__).resolve().parent.parent / "data" / "college_information.json"

def load_knowledge_base():
    with open(DATA_PATH, "r", encoding="utf-8") as f:
        return json.load(f)

def local_search(question, data):
    """Simple keyword retrieval fallback. Keeps the project runnable without cloud credentials."""
    q = question.lower()
    results = []
    for item in data["documents"]:
        text = (item["title"] + " " + item["content"] + " " + " ".join(item["keywords"])).lower()
        score = sum(1 for word in q.split() if len(word) > 2 and word in text)
        if score:
            results.append((score, item))
    results.sort(key=lambda x: x[0], reverse=True)
    return [x[1] for x in results[:4]]

def build_context(results):
    return "\n\n".join(
        f"[{item['title']}]\n{item['content']}" for item in results
    )

def generate_with_gemini(question, context):
    try:
        from google import genai
        from google.genai.types import GenerateContentConfig

        project = os.getenv("GOOGLE_CLOUD_PROJECT")
        location = os.getenv("GOOGLE_CLOUD_LOCATION", "global")

        if not project:
            return None

        client = genai.Client(
            vertexai=True,
            project=project,
            location=location
        )

        prompt = f"""
You are a college information assistant.

Answer the student's question using ONLY the provided college knowledge base.
If the answer is not available, clearly say that the information is not present
in the current knowledge base. Do not invent fees, dates, rules, contacts, or
other college facts.

College knowledge base:
{context}

Student question:
{question}

Give a concise, helpful answer. Mention relevant source titles when useful.
"""
        response = client.models.generate_content(
            model=os.getenv("GEMINI_MODEL", "gemini-2.5-flash"),
            contents=prompt,
            config=GenerateContentConfig(
                temperature=0.2,
                max_output_tokens=500
            )
        )
        return response.text
    except Exception:
        return None

def answer_question(question):
    data = load_knowledge_base()
    results = local_search(question, data)

    if not results:
        return (
            "I couldn't find relevant information in the college knowledge base. "
            "Please contact the college office or add the required information to "
            "`data/college_information.json`."
        ), []

    context = build_context(results)
    ai_answer = generate_with_gemini(question, context)

    if ai_answer:
        return ai_answer, [item["title"] for item in results]

    # Offline/local fallback
    answer = (
        "Here is the relevant information from the college knowledge base:\n\n"
        + "\n\n".join(
            f"**{item['title']}**\n{item['content']}" for item in results[:2]
        )
    )
    return answer, [item["title"] for item in results[:2]]
