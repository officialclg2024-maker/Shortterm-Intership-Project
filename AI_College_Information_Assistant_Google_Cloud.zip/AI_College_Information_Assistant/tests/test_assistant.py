import sys
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parents[1]))

from src.assistant import load_knowledge_base, local_search

def test_knowledge_base_loads():
    data = load_knowledge_base()
    assert "documents" in data
    assert len(data["documents"]) > 0

def test_admission_search():
    data = load_knowledge_base()
    results = local_search("What is the admission process?", data)
    assert len(results) > 0
